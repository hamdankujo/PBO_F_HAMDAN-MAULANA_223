package perpustakaan;

public interface Peminjaman {
    void pinjamBuku(Buku buku);
    void kembalikanBuku(Buku buku);
}
